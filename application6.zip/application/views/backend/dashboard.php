<?php
echo getconfig("projectname");
?>