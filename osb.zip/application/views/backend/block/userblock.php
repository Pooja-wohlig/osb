<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/viewshopphoto?id=').$before->id; ?>">Shop Photo</a></li>
<li><a href="<?php echo site_url('site/viewshopproductphoto?id=').$before->id; ?>">Shop Product Photo</a></li>
<li><a href="<?php echo site_url('site/viewusercategory?id=').$before->id; ?>">User Category</a></li>
</ul>
</div>
</section>