<section class="panel">

    <div class="panel-body">
        <ul class="nav nav-stacked">
            <li><a href="<?php echo site_url('site/editproduct?id=').$before['product']->id; ?>">Product Details</a></li>
            <li><a href="<?php echo site_url('site/viewproductimages?id=').$before['product']->id; ?>">Image</a></li>
        </ul>
    </div>
</section>